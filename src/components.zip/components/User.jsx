import React from 'react'
import { Image } from 'react-bootstrap'

const User = () => {
  return (
    <Image style={{ width: '50px', height: '50px', borderRadius: '50%'}} src='./images/Sudi.jpeg'></Image>
  )
}

export default User
